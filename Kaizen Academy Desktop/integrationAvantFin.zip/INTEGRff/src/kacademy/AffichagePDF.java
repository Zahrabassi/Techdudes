/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package kacademy;

import com.adobe.acrobat.Viewer;
import java.awt.BorderLayout;
import java.io.FileInputStream;
import javax.swing.JPanel;

/**
 *
 * @author user
 */
public class AffichagePDF extends JPanel{
     private Viewer viewer1;

    public AffichagePDF(String nomFichier) throws Exception{
    this.setLayout(new BorderLayout());
    
    viewer1 = new Viewer();
    FileInputStream fis =new FileInputStream(nomFichier);
    viewer1.setDocumentInputStream(fis);
    this.add(viewer1,BorderLayout.CENTER);
    viewer1.activate();
}
}
