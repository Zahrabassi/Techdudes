/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package kacademy;

import javafx.scene.input.MouseEvent;

/**
 *
 * @author user
 */
public class envoyerMailController {
 
    public void supprimerCliquer(MouseEvent event){
    
    }
       public void modifierCliquer (MouseEvent event){
           
       }
       
      public void infosEnseignantCliquer (MouseEvent event){
          
      }
}
