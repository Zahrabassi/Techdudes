/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package kacademy;

import kacademy.entity.User;

/**
 *
 * @author LENOVO
 */
public class Session {
    public static int    id_etud = 1 ;
    public static User user ;
}
