/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package kacademy;

import java.io.IOException;
import java.net.URL;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import static java.util.Collections.list;
import java.util.List;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.collections.transformation.SortedList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ListCell;
import javafx.scene.control.ListView;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;
import javafx.util.Callback;
import kacademy.dao.FormationDao;
import kacademy.entity.Cour;
import kacademy.entity.Formation;

/**
 * FXML Controller class
 *
 * @author 21655
 */
public class EtudiantCourController implements Initializable {

       @FXML
    private TableColumn<Cour,String> colNomC;
    @FXML
    private TableColumn<Cour,String> ColNomEn;
    @FXML
    private TableColumn<Cour,String>Coldesc;
    @FXML
    private TableView<Cour> tcCourEtu;
    @FXML
    private TextField Rech;
    @FXML
    private ImageView img_logo;
    @FXML
    private ImageView img_logo1;
    @FXML
    private ImageView imgLog;
    @FXML
    private ImageView imgEmp;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        showCour();
        img_logo1.setImage(new Image(Paths.get("").toAbsolutePath().toUri().toString()+"/icons/ka_logo.png"));
    }    
   public Connection getConnection(){
        Connection conn;
        try{
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/kadb", "root","");
            return conn;
        }catch(Exception ex){
            System.out.println("Error: " + ex.getMessage());
            return null;
        }
  
    }
     
      public ObservableList<Cour> getCourList(){
        ObservableList<Cour> courList = FXCollections.observableArrayList();
        Connection conn = getConnection();
String query = "SELECT cour.*, cour.nomCour AS nomCour , cour.nomEnseignant AS nomEnseignant FROM cour ";
        Statement st;
        ResultSet rs;
        
       try{
            st = conn.createStatement();
            rs = st.executeQuery(query);
            Cour cour;
            while(rs.next()){
             courList.add(new  Cour(
             rs.getInt("idC"),
             rs.getString("nomCour"),
             rs.getString("nomEnseignant"),
             rs.getString("description")));
                       
            }
                
        }catch(Exception ex){
            ex.printStackTrace();
        }
       
        
      
        return courList;
    }
    
       public void showCour(){
           
           
           
           
        ObservableList<Cour> list = getCourList(); 
        colNomC.setCellValueFactory(new PropertyValueFactory<Cour, String>("nomCour"));
        ColNomEn.setCellValueFactory(new PropertyValueFactory<Cour, String>("nomEnseignant"));
        Coldesc.setCellValueFactory(new PropertyValueFactory<Cour, String>("description"));
       
        
        tcCourEtu.setItems(list);
          FilteredList<Cour> filteredData = new FilteredList<>(list, b -> true);

		Rech.textProperty().addListener((observable, oldValue, newValue) -> {
			filteredData.setPredicate(cr -> {
											
				if (newValue == null || newValue.isEmpty()) {
					return true;
				}
				String lowerCaseFilter = newValue.toLowerCase();
				
				if (cr.getNomCour().toLowerCase().indexOf(lowerCaseFilter) != -1 ) {
					return true; // Filter matches first name.
				} else if (cr.getNomEnseignant().toLowerCase().indexOf(lowerCaseFilter) != -1 ) {
					return true; // Filter matches first name.
				} 
				     else  
				    	 return false; // Does not match.
			});
		});
		
		
		SortedList<Cour> sortedData = new SortedList<>(filteredData);
		
		sortedData.comparatorProperty().bind(tcCourEtu.comparatorProperty());
		
		tcCourEtu.setItems(sortedData);
                
                
                
       
       }
       

  

       @FXML
    private void goToHome(ActionEvent event) throws IOException {
         Node node = (Node) event.getSource();
                    Stage stage = (Stage) node.getScene().getWindow();
                    stage.close();

                      Scene scene = new Scene(FXMLLoader.load(getClass().getResource("views/MenuEtu.fxml")));
                    stage.setScene(scene);
                    stage.show();
    }
}
