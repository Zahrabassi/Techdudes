/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package kacademy;

import java.net.URL;
import java.nio.file.Paths;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import kacademy.dao.UserDao;
import kacademy.entity.User;

/**
 * FXML Controller class
 *
 * @author LENOVO
 */
public class LoginController implements Initializable {
    
    @FXML
    private TextField txt_username ;
    @FXML
    private TextField txt_pass ;
    @FXML
    private Button btn_login ;
    @FXML
    private Label lb_err ;
    @FXML
    private ImageView img_logo ;
    

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
        img_logo.setImage(new Image(Paths.get("").toAbsolutePath().toUri().toString()+"/icons/ka_logo.png"));
        
        btn_login.setOnAction(e->{
            lb_err.setText("");
            UserDao u_dao = UserDao.getInstance();
            User u = u_dao.doLogin(txt_username.getText(), txt_pass.getText());
            if(u != null){
                Session.user = u ;
                System.out.println("user :"+u);
                if("Admin".equals(u.getRole())){
                    HomeShopController.getInstance().goMenuAdmin();
                }else if("Etudiant".equals(u.getRole())){
                    HomeShopController.getInstance().goMenuEtudant();
                }else if ("Enseingant".equals(u.getRole())){
                    HomeShopController.getInstance().goMenuEns();
                }
            }else{
                lb_err.setText("user ou mot de passe incorrect !");
            }
        });
        // TODO
    }    
    
}
